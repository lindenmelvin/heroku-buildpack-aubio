Current status
==============

.. image:: https://travis-ci.org/aubio/aubio.svg?branch=master
   :target: https://travis-ci.org/aubio/aubio
   :alt: Travis build status

.. image:: https://ci.appveyor.com/api/projects/status/f3lhy3a57rkgn5yi?svg=true
   :target: https://ci.appveyor.com/project/piem/aubio/
   :alt: Appveyor build status

.. image:: https://readthedocs.org/projects/aubio/badge/?version=latest
   :target: https://aubio.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation status

.. image:: https://img.shields.io/github/commits-since/aubio/aubio/latest.svg
   :target: https://github.com/aubio/aubio
   :alt: Commits since last release


